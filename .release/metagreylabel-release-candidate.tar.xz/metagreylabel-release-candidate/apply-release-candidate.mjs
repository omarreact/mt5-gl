import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const BUNDLE = path.dirname(fileURLToPath(import.meta.url));
const TARGET = path.resolve(process.argv[2] || process.cwd());

const required = [
  "build.mjs",
  ".github/workflows/pages.yml",
  "content.xml",
  "templates/bitrader-1.html",
  "css/bitrader.css",
  "js/bitrader.js",
  "media/logo-light.svg",
  "media/logo-dark.svg",
  "media/logo-symbol.svg",
  "media/favicon.svg",
  "media/favicon-32.png",
  "media/apple-touch-icon.png",
  "media/icon-192.png",
  "media/icon-512.png"
];

for (const relative of required) {
  const absolute = path.join(TARGET, relative);
  if (!fs.existsSync(absolute)) throw new Error(`Expected repository file is missing: ${relative}`);
}

function copy(relativeSource, relativeTarget) {
  const source = path.join(BUNDLE, relativeSource);
  const target = path.join(TARGET, relativeTarget);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.copyFileSync(source, target);
}

function move(relativeSource, relativeTarget) {
  const source = path.join(TARGET, relativeSource);
  const target = path.join(TARGET, relativeTarget);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  if (fs.existsSync(target)) fs.rmSync(target, { force: true });
  fs.renameSync(source, target);
}

function formatCss(css) {
  let output = "";
  let indent = 0;
  let quote = "";
  let comment = false;
  let parens = 0;
  let pendingSpace = false;

  const newline = () => {
    output = output.replace(/[ \t]+$/g, "");
    if (!output.endsWith("\n")) output += "\n";
    output += "  ".repeat(Math.max(0, indent));
    pendingSpace = false;
  };

  for (let index = 0; index < css.length; index += 1) {
    const char = css[index];
    const next = css[index + 1];

    if (comment) {
      output += char;
      if (char === "*" && next === "/") {
        output += "/";
        index += 1;
        comment = false;
      }
      continue;
    }

    if (quote) {
      output += char;
      if (char === "\\" && next) {
        output += next;
        index += 1;
      } else if (char === quote) {
        quote = "";
      }
      continue;
    }

    if (char === "/" && next === "*") {
      if (output.trim() && !output.endsWith("\n")) newline();
      output += "/*";
      index += 1;
      comment = true;
      continue;
    }

    if (char === '"' || char === "'") {
      if (pendingSpace && output && !/[\s({,:]$/.test(output)) output += " ";
      pendingSpace = false;
      quote = char;
      output += char;
      continue;
    }

    if (char === "(") {
      parens += 1;
      output += char;
      continue;
    }

    if (char === ")") {
      parens = Math.max(0, parens - 1);
      output += char;
      continue;
    }

    if (/\s/.test(char)) {
      pendingSpace = true;
      continue;
    }

    if (pendingSpace) {
      if (output && !/[\s({,:;]$/.test(output) && !/[)}>,:;]/.test(char)) output += " ";
      pendingSpace = false;
    }

    if (char === "{" && parens === 0) {
      output = output.trimEnd() + " {";
      indent += 1;
      newline();
      continue;
    }

    if (char === ";" && parens === 0) {
      output += ";";
      newline();
      continue;
    }

    if (char === "}" && parens === 0) {
      indent = Math.max(0, indent - 1);
      output = output.trimEnd();
      if (!output.endsWith("\n")) output += "\n";
      output += "  ".repeat(indent) + "}";
      if (next && next !== ";" && next !== "," && next !== "}") newline();
      continue;
    }

    if (char === "," && parens === 0) {
      output += ",";
      if (indent === 0) newline();
      continue;
    }

    output += char;
  }

  return output.trim() + "\n";
}

const cssSource = fs.readFileSync(path.join(TARGET, "css/bitrader.css"), "utf8");
const sliderMarker = "/* MetaGreyLabel one-homepage adaptive hero slider */";
const markerIndex = cssSource.indexOf(sliderMarker);
const legacyCss = markerIndex >= 0 ? cssSource.slice(0, markerIndex) : cssSource;
const additions = fs.readFileSync(path.join(BUNDLE, "css/style.append.css"), "utf8");

fs.writeFileSync(
  path.join(TARGET, "css/style.css"),
  `${formatCss(legacyCss)}\n${additions.trim()}\n`,
  "utf8"
);
fs.rmSync(path.join(TARGET, "css/bitrader.css"));

copy("build.mjs", "build.mjs");
copy(".github/workflows/pages.yml", ".github/workflows/pages.yml");
copy("js/script.js", "js/script.js");
fs.rmSync(path.join(TARGET, "js/bitrader.js"));
copy("site.webmanifest", "site.webmanifest");

const templatePath = path.join(TARGET, "templates/bitrader-1.html");
let template = fs.readFileSync(templatePath, "utf8");
template = template
  .replace(/<link rel="stylesheet" href="[^"]*bitrader\.css">/i, '<link rel="stylesheet" href="../css/style.css">')
  .replace(/<script src="[^"]*bitrader\.js"[^>]*><\/script>/gi, "")
  .replace(/\.\.\/media\/logo-header\.svg/g, "../media/branding/logo-light.svg")
  .replace(/\.\.\/media\/logo-footer\.svg/g, "../media/branding/logo-light.svg")
  .replace(/\.\.\/media\/logo-symbol\.svg/g, "../media/branding/logo-symbol.svg")
  .replace(/\.\.\/media\/favicon\.svg/g, "../media/branding/favicon.svg")
  .replace(/\.\.\/media\/favicon-32\.png/g, "../media/branding/favicon-32.png")
  .replace(/\.\.\/media\/apple-touch-icon\.png/g, "../media/branding/apple-touch-icon.png")
  .replace(/\.\.\/media\/icon-192\.png/g, "../media/branding/icon-192.png")
  .replace(/\.\.\/media\/icon-512\.png/g, "../media/branding/icon-512.png");
if (!/js\/script\.js/.test(template)) {
  template = template.replace("</head>", '  <script src="../js/script.js"></script>\n</head>');
}
fs.writeFileSync(templatePath, template, "utf8");

for (const file of ["logo-light.svg", "logo-dark.svg", "logo-symbol.svg", "favicon.svg"]) {
  copy(`branding/${file}`, `media/branding/${file}`);
  fs.rmSync(path.join(TARGET, "media", file), { force: true });
}

for (const file of ["favicon-32.png", "apple-touch-icon.png", "icon-192.png", "icon-512.png"]) {
  move(`media/${file}`, `media/branding/${file}`);
}

console.log(JSON.stringify({
  target: TARGET,
  stylesheet: "css/style.css",
  script: "js/script.js",
  brandingDirectory: "media/branding",
  generator: "build.mjs",
  manifest: "site.webmanifest"
}, null, 2));
